#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void rev(char *l,char *r)
{
        while(l<r)
        {
                int temp=*l;
                *l=*r;
                *r=temp;
                r--;
                l++;
        }
}
char *copytobuf(char *filename,int n)
{
	FILE *fp;
	char *buf=NULL;
	int size;
	if(n!=3)
	{
		printf("enter proper input :- a.out filename");
		exit(0);
	}
	fp=fopen(filename,"r");
	if(fp==NULL)
	{
		printf("file is not found");
		exit(0);
	}
	fseek(fp,0,2);
	size=ftell(fp)+1;
	rewind(fp);
	buf=calloc(1,size);
	fread(buf,size-1,1,fp);
	buf[size]='\0';
	fclose(fp);
	return buf;
}
void writetofile(char *p,char *filename)
{
	FILE *fp;
	fp=fopen(filename,"w");
	fwrite(p,strlen(p),1,fp);
	fclose(fp);
}
void main(int argc,char **argv)
{
	FILE *fp;
	char str[100];
	char *buf=NULL;
	if(argc!=3)
	{
		printf("enter a proper input:- a.out filename");
		exit(0);
	}
	fp=fopen(argv[1],"r");
	if(fp==NULL)
	{
		printf("file is not found");
		exit(0);
	}
	buf=copytobuf(argv[1],argc);
        char *p=NULL,*sub;
	p=buf;
	sub=argv[2];
	while(p=strstr(p,sub))
	{
		//rev(p,p+strlen(sub)-1);
		//memset(p,'*',strlen(sub));
		memmove(p,p+strlen(sub),strlen(p+strlen(sub))+1);
		p--;
		p=p+strlen(sub);
	}
	//rev(buf,buf+strlen(buf)-1);
	puts(buf);
	writetofile(buf,argv[1]);
}
